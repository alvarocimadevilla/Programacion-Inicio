package es.daw.model;


public class Tarea {

    // ---------------------------
    // CONSTANTES
    // ---------------------------
    private static final int PRIORIDAD_DEFECTO = 3;
    private static final int LONGITUD = 40;
    
    // IMPORTANTE PARA CODIFICAR: cada letra se corresponde al código en su misma posición
    // Sustituye cada letra por su código y al revés para descodificar
    private static final char[] LETRAS = {'a','e','i','o','u'};
    private static final char[] CODIGOS = {'&','%','$','#','@'};
    
    // ---------------------------
    // ATRIBUTOS
    // ---------------------------

    
    // ---------------------------
    // CONSTRUCTORES
    // ---------------------------

    
    // ---------------------------
    // GETTERS & SETTERS
    // ---------------------------

    
    // ---------------------------
    // MÉTODOS PROPIOS
    // ---------------------------
    public boolean codificar(){
        
        // pendiente completar...
        
        return true;
    }
    
    public boolean descodificar(){
        
        // pendiente completar...
        return true;
    }
    
    
    // ---------------------------
    // @Override toString()
    // ---------------------------

    
}
