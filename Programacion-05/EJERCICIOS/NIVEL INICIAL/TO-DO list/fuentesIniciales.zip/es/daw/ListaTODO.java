package es.daw;

/*
 * Módulo de Programación
 * Examen primera evaluación 2022-23
 * Ejercicio 2
 */

public class ListaTODO {
    
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("*********************************");
        System.out.println("****** APP DE LISTAS TO-DO ******");
        System.out.println("*Simulacro de lista con 5 tareas*");
        System.out.println("*********************************");
        
        // ---------
        // PASO 1
        // ---------
        // DAR DE ALTA LAS 5 TAREAS EN LA LISTA SEGÚN ESPECIFICACIONES
        /*
        Tarea 1:
        Descripción: Mi primera tarea
        Fecha límite: 2022-12-01
        Prioridad: 3

        Tarea 2:
        Descripción: Tengo que estudiar mucho Programación para aprobar
        Fecha límite: 2022-12-02
        Prioridad: 2

        Tarea 3:
        Descripción: Tengo que estudiar mucho LM
        Fecha límite: 2022-12-03

        Tarea 4:
        Descripción: En Navidad voy a repasar todos los ejercicios del GitHub
        Fecha límite: 2022-12-04
        Prioridad: 1

        Tarea 5:
        Descripción: Mi última tarea        
        */
        

        
        // ---------
        // PASO 2
        // ---------
        // CODIFICAR LA ÚLTIMA TAREA Y HACER LAS PRUEBAS PERTINENTES DE CODIFICACIÓN/DESCODIFICACIÓN
        // Sigue las trazas del enunciado



        
        // ---------
        // PASO 3
        // ---------
        // MOSTAR TODAS LA TAREAS RECORRIENDO LA LISTA


        
        // ---------
        // PASO 4
        // ---------
        // FINALIZAR LA TAREAS 2 Y 3
        
        
        // MOSTRAR LAS TAREAS FINALIZADAS SEGÚN LO ESPECIFICADO EN EL ENUNCIADO


        
    }
    
}
