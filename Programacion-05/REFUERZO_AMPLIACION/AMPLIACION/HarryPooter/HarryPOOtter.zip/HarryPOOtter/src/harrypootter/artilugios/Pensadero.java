package harrypootter.artilugios;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * La clase Pensadero te ayudará a guardar las memorias y a extraer todas ellas
 * en un tomo mágico.
 */
public class Pensadero {
    
    ArrayList<String> memorias;
    
    public Pensadero(){
        this.memorias = new ArrayList<String>();
    }
    
    /**
     * Entrega una memoria al pensadero para que la almacene.
     */
    public void legarRecuerdo(String recuerdo){
        memorias.add(recuerdo);
    };
    
    /**
     * Sublimar los recuerdos del pensadero permitirá la transcripción de las
     * memorias a un tomo mágico.
     * @param tomoDelArchivo ruta y nombre del archivo que contendrá la 
     * información si no se especifica ruta será la misma del proyecto. 
     * Asegurate de usar la extensión de archivo deseada.
     */
    public void sublimarRecuerdos(String tomoDelArchivo){
        try {
            FileWriter plumaMagica = new FileWriter(tomoDelArchivo);
            BufferedWriter pergaminoDeAcebo = new BufferedWriter(plumaMagica);

            for(String memoria : memorias){
                pergaminoDeAcebo.write(memoria + "\n");
            }

            pergaminoDeAcebo.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
