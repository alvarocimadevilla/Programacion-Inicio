package harrypootter.alumnado;

import harrypootter.artilugios.InformacionParaMuggles;
import harrypootter.hogwarts.Afinidad;
import harrypootter.hogwarts.EnumCasa;

public class AlumnoRavenclaw extends Alumno implements InformacionParaMuggles {
    

    public AlumnoRavenclaw(String nombre, int cursoIngreso, Excelencia excelencia, Afinidad afinidad){
        super(nombre, cursoIngreso, excelencia, afinidad);
        this.casa = EnumCasa.RAVENCLAW;
        this.logrosPositivos = new String[]{"Sabiduría","Participación en Actividades Artísticas","Liderazgo en Proyectos Académicos","Innovación en Hechizos","Participación Activa en el Club de Duelo"};
        this.accionesNegativas = new String[]{"Deslealtad en Proyectos Académicos Grupales","Uso Inapropiado de Conocimientos Mágicos","Negligencia en el Cuidado de Libros y Documentos","Menospreciar las Ideas de Otros Estudiantes","Plagio o Copia en Tareas"};
    }
}
