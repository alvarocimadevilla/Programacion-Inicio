/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package harrypootter.hogwarts;

/**
 *
 * @author jar
 */
public class Incidencia {
    private boolean positiva;
    private String infoIncidencia;
    private int valorPuntuacion;

    public Incidencia(boolean positiva, String infoIncidencia, int valorPuntuacion) {
        this.positiva = positiva;
        this.infoIncidencia = infoIncidencia;
        this.valorPuntuacion = valorPuntuacion;
    }

    public boolean isPositiva() {
        return positiva;
    }

    public String getInfoIncidencia() {
        return infoIncidencia;
    }

    public int getValorPuntuacion() {
        return valorPuntuacion;
    }
    
    @Override
    public String toString(){
        return (positiva?"Premio: ":"Castigo: ") + infoIncidencia + " (" + valorPuntuacion + " puntos).";
    }
    
    
}
