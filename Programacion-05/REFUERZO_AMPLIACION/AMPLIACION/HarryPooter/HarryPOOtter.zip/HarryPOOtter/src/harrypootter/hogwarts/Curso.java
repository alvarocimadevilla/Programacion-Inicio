/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package harrypootter.hogwarts;

import harrypootter.artilugios.InformacionParaMuggles;
import java.util.ArrayList;

/**
 *
 * @author jar
 */
public class Curso implements InformacionParaMuggles {
    public ArrayList<Asignatura> asignaturas;
    private int promocion;

    public Curso(int promocion) {
        asignaturas = new ArrayList<>();
        this.promocion = promocion;
    }

    public int getPromocion() {
        return promocion;
    }
    
    @Override
    public String toString(){
        return "----------------- Promoción: " + promocion + " -----------------";
    }
    
    
    
    
}
