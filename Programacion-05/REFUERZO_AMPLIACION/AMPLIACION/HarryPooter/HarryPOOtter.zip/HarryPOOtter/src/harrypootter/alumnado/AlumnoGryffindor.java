package harrypootter.alumnado;

import harrypootter.artilugios.InformacionParaMuggles;
import harrypootter.hogwarts.Afinidad;
import harrypootter.hogwarts.EnumCasa;

public class AlumnoGryffindor extends Alumno implements InformacionParaMuggles{

    
    
    
    public AlumnoGryffindor(String nombre, int cursoIngreso, Excelencia excelencia, Afinidad afinidad){
        super(nombre, cursoIngreso, excelencia, afinidad);
        this.casa = EnumCasa.GRYFFINDOR;
        this.logrosPositivos = new String[]{"Valentía","Ayuda a Amigos","Defensa de los Más Débiles","Creatividad en Solución de Problemas","Contribución a la Comunidad"};
        this.accionesNegativas = new String[]{"Irresponsabilidad en Situaciones Peligrosas","Desobedecer Normas de Seguridad en Clases Prácticas","Descuido en el Mantenimiento de Equipo Mágico","Falta de Respeto hacia la Autoridad","Descuido en las Tareas Asignadas"};
    }
    
}
