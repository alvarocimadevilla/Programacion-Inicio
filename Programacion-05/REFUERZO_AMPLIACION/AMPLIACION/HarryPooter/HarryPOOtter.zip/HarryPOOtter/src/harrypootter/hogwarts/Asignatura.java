package harrypootter.hogwarts;

public class Asignatura {
    private Asignaturas info;
    private Profesor profesor;
    //private double calificacion;

    public Asignatura(Asignaturas info, Profesor profesor) {
        this.info = info;
        this.profesor = profesor;
        //this.calificacion = -1;
    }

    public Asignaturas getInfo() {
        return info;
    }

    public Profesor getProfesor() {
        return profesor;
    }

//    public double getCalificacion() {
//        return calificacion;
//    }
//
//    public void setCalificacion(double calificacion) {
//        this.calificacion = calificacion;
//    }
    
    @Override
    public String toString(){
        return info.getNombre() + " de " + info.getCurso() + 
                "º curso, impartida por " + profesor.getNombre() + ".";
        
    }
    
    
    
    
}
