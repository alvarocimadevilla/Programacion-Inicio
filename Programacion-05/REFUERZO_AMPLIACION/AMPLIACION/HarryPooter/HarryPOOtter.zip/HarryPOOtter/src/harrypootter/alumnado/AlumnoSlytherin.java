package harrypootter.alumnado;

import harrypootter.artilugios.InformacionParaMuggles;
import harrypootter.hogwarts.Afinidad;
import harrypootter.hogwarts.EnumCasa;

public class AlumnoSlytherin extends Alumno implements InformacionParaMuggles {
    

public AlumnoSlytherin(String nombre, int cursoIngreso, Excelencia excelencia, Afinidad afinidad){
        super(nombre, cursoIngreso, excelencia, afinidad);
        this.casa = EnumCasa.SLYTHERIN;
        this.logrosPositivos = new String[]{"Astucia","Liderazgo","Éxito en Duelos Mágicos","Lealtad a la Casa","Resolución de Conflictos"};
        this.accionesNegativas = new String[]{"Traición a la Casa","Manipulación Desleal","Falta de Lealtad hacia Compañeros de Casa","Desprecio hacia Sangre No Pura","Desafío Abierto a la Autoridad de la Casa"};
    }
}
