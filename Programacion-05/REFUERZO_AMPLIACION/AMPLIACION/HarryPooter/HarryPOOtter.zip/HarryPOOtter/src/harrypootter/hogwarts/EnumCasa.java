package harrypootter.hogwarts;


public enum EnumCasa {
    
GRYFFINDOR,
HUFFLEPUFF,
RAVENCLAW,
SLYTHERIN; 
    
    
}
