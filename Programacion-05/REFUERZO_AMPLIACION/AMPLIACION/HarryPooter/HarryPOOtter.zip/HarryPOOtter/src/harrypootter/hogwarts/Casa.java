package harrypootter.hogwarts;


public class Casa {
    // selección jugadores quidditch
    // los 5 mejores en vuelo y encantamiento
    // afinidad antiley o arcana da 1 
    

}
