package harrypootter.alumnado;

import harrypootter.artilugios.InformacionParaMuggles;
import harrypootter.hogwarts.Afinidad;
import harrypootter.hogwarts.Asignatura;
import harrypootter.hogwarts.Asignaturas;
import harrypootter.hogwarts.Curso;
import harrypootter.hogwarts.EnumCasa;
import harrypootter.hogwarts.Incidencia;
import java.util.ArrayList;

public abstract class Alumno implements InformacionParaMuggles {
    
    private static final int NUMERO_CURSOS = 7;
    protected String nombre;
    protected int promocion;
    protected Excelencia excelencia;
    protected Afinidad afinidad;
    protected EnumCasa casa;
    protected Expediente expediente;
    protected String[] logrosPositivos;
    protected String[] accionesNegativas;

    public Alumno(String nombre, int promocion, Excelencia excelencia, Afinidad afinidad) {
        this.nombre = nombre;
        this.promocion = promocion;
        this.excelencia = excelencia;
        this.afinidad = afinidad;
        expediente = new Expediente();
    }
    
    public void matricularCurso(Curso curso){

        if(actualAlumno(curso.getPromocion())){
            int cursoAMatricular = curso.getPromocion() - this.promocion + 1;
            for(Asignatura a: curso.asignaturas){
                if(a.getInfo().getCurso() == cursoAMatricular){
                    expediente.addAsignatura(a);
                }
            }
        } 
        
    }
    
    public boolean actualAlumno(int promocion){
        return (promocion >= this.promocion && 
                promocion < this.promocion + NUMERO_CURSOS);
    }
    
    
    public void obtenerResultadosAcademicos(){
        for(int i = 0; i < expediente.getAsignaturas().size(); i++){
            if(expediente.getCalificaciones().get(i) < 0){
                
                double d = calificar(
                        expediente.getAsignaturas().get(i).getInfo().getAfinidad(), 
                        expediente.getAsignaturas().get(i).getProfesor().getAfinidad());
                expediente.getCalificaciones().set(i, d);
            }
        }
    }
    
    private double calificar(Afinidad afinAsignatura, Afinidad afinProfesor){
        double nota = Math.random()*10, ren = this.excelencia.rendimiento();
        nota = nota * ren;
        nota += ren * ren * ren;
        if(this.afinidad == afinAsignatura){
            nota += 0.5d;
        }
        if(afinAsignatura == afinAsignatura){
            nota += 0.5d;
        }
        if(this.afinidad == afinAsignatura && this.afinidad == afinProfesor){
            nota += 2;
        }
        return Math.min(nota, 10);
    }
    
    public double notaMedia(){
        double notas = 0, numAsig= expediente.getAsignaturas().size();
        
        for(Double nota : expediente.getCalificaciones()){
            notas += nota;
        }
        return notas / numAsig;
    }
    
    public int puntuacionParaLaCasa(){
        int puntos = 0; 
        
        for(int i = 0; i < expediente.incidencias.size(); i++){
            puntos += expediente.incidencias.get(i).getValorPuntuacion();
        }
        return puntos;
    }
    
    public int aportacionGlobalAHogwarts(){
        return (int)(notaMedia()*100 + puntuacionParaLaCasa());
    }
    
    public void generarIncidencias(int promocion){
        if(actualAlumno(promocion)){
            switch (this.excelencia) {
                case NORMAL:
                    int r1 = (int)(Math.random()*4 + 1), r2, r3;
                    if(r1 == 3){
                        r2 = (int)(Math.random()*3 + 1);
                        r3 = (int)(Math.random()*logrosPositivos.length);
                        expediente.incidencias.add(new Incidencia(true, logrosPositivos[r3], r2));
                    } else if(r1 == 4){
                        r2 = (int)(Math.random()*3 + 1);
                        r3 = (int)(Math.random()*accionesNegativas.length);
                        expediente.incidencias.add(new Incidencia(false, accionesNegativas[r3], r2*-1));
                    }
                    break;
                case SEMIMUGGLE:
                        r2 = (int)(Math.random()*3 + 1);
                        r3 = (int)(Math.random()*accionesNegativas.length);
                        expediente.incidencias.add(new Incidencia(false, accionesNegativas[r3], r2*-1));
                    break;
                case VIRTUOSO:
                        r2 = (int)(Math.random()*3 + 1);
                        r3 = (int)(Math.random()*logrosPositivos.length);
                        expediente.incidencias.add(new Incidencia(true, logrosPositivos[r3], r2));
                    break;
                case LEYENDA:
                        for (int i = 0; i < 3; i++) {
                            r2 = (int)(Math.random()*3 + 1);
                            r3 = (int)(Math.random()*logrosPositivos.length);
                            expediente.incidencias.add(new Incidencia(true, logrosPositivos[r3], r2));
                        }
                    break;
                default:
                    break;
            }
        }
    }

    public EnumCasa getCasa() {
        return casa;
    }

    public Expediente getExpediente() {
        return expediente;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPromocion() {
        return promocion;
    }

    public Afinidad getAfinidad() {
        return afinidad;
    }
    
    
    
    @Override
    public String toString(){
        String cad = "### ALUMNO: " + nombre + "\n";
        cad += "-Promoción: " + promocion + "\n";
        cad += "-Casa: " + casa.toString() + "\n";
        cad += "-Afinidad: " + afinidad.toString() + "\n";
        cad += "-Excelencia: " + excelencia.toString() + "\n";
        cad += "-Media: " + String.format("%.2f", notaMedia()) + "\n";
        cad += "-Puntuación para la casa: " + puntuacionParaLaCasa() + "\n";
        cad += "-Aportación global a Hogwarts: " + aportacionGlobalAHogwarts() + "\n";
        cad += expediente.toString() + "\n";

        
        return cad;
    }
    
    
    
    
    
}
