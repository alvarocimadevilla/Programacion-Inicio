package harrypootter.hogwarts;

import harrypootter.artilugios.InformacionParaMuggles;

public class Profesor implements InformacionParaMuggles {
    protected String nombre;
    protected Afinidad afinidad;

    public Profesor(String nombre, Afinidad afinidad) {
        this.nombre = nombre;
        this.afinidad = afinidad;
    }

    public String getNombre() {
        return nombre;
    }

    public Afinidad getAfinidad() {
        return afinidad;
    }
    
    @Override
    public String toString(){
        return nombre + ". Profesor especialista en " + afinidad.name() + ".";
    }
    
}
