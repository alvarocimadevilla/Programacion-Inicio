package harrypootter.hogwarts;


public enum Afinidad {
    NATURAL,
    ARCANA,
    ANTILEY,
    OSCURIDAD;
    
    public static Afinidad generarAfinidadAleatoria(){
        int rnd = (int)(Math.random()*100);
        if(rnd < 25){
            return NATURAL;
        } else if(rnd < 50){
            return ARCANA;
        } else if(rnd < 75){
            return ANTILEY;
        } else{
            return OSCURIDAD;
        }    
    }
}
