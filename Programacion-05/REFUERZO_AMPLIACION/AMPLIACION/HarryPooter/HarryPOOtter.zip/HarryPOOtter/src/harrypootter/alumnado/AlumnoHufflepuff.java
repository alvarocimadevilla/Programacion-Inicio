package harrypootter.alumnado;

import harrypootter.artilugios.InformacionParaMuggles;
import harrypootter.hogwarts.Afinidad;
import harrypootter.hogwarts.EnumCasa;

public class AlumnoHufflepuff extends Alumno implements InformacionParaMuggles {
   
    public AlumnoHufflepuff(String nombre, int cursoIngreso, Excelencia excelencia, Afinidad afinidad){
        super(nombre, cursoIngreso, excelencia, afinidad);
        this.casa = EnumCasa.HUFFLEPUFF;
        this.logrosPositivos = new String[]{"Lealtad","Acto de Bondad Inesperada","Excelencia en Herbología","Contribución a la Felicidad","Respeto por la Diversidad"};
        this.accionesNegativas = new String[]{"Falta de Colaboración en Trabajo en Equipo","Actos Egoístas en Situaciones de Ayuda","Negligencia en el Cuidado de Criaturas Mágicas","Falta de Apoyo a Compañeros de Casa","Incumplimiento de Compromisos o Promesas"};
    }    
}
