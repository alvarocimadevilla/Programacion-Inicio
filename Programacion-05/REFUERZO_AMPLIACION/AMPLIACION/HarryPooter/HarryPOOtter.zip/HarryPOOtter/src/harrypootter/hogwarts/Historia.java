/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package harrypootter.hogwarts;

import harrypootter.alumnado.Alumno;
import harrypootter.alumnado.AlumnoGryffindor;
import harrypootter.alumnado.AlumnoHufflepuff;
import harrypootter.alumnado.AlumnoRavenclaw;
import harrypootter.alumnado.AlumnoSlytherin;
import harrypootter.alumnado.Excelencia;
import harrypootter.artilugios.InformacionParaMuggles;
import harrypootter.artilugios.GenerardorNombresMagos;
import java.util.ArrayList;

/**
 *
 * @author jar
 */
public class Historia implements InformacionParaMuggles {
    private static final int NUMERO_PROFESORES = 40;
    Profesor[] claustro;
    Curso[] promociones;
    ArrayList<Alumno> alumnado;

    public Historia(int numeroPromnociones) {
        this.claustro = new Profesor[NUMERO_PROFESORES];
        this.promociones =new Curso[numeroPromnociones];
        this.alumnado = new ArrayList<Alumno>();
    }
    
    public void generarClaustro(){
        // para generar claustro generamos 10 profesores de cada afinidad
        int contador = 0;
        for(Afinidad a : Afinidad.values()){
            for (int i = 0; i < 10; i++) {
                this.claustro[contador] = new Profesor(GenerardorNombresMagos.generarNombre(), a);
                contador++;
            }
        }
    
    }
    
    public void generarAlumnos(int promocion){
        // genera un número aleatorio (entre 90 y 100) de nuevos 
        // alumnos que entran al primer curso
        int alumnosNuevos = (int)(Math.random() * 11 + 90);
        for (int i = 0; i < alumnosNuevos; i++) {
            int casa = (int)(Math.random() * 4);
            switch (casa) {
                case 0:
                    alumnado.add(new AlumnoGryffindor(
                    GenerardorNombresMagos.generarNombre(), 
                    promocion, 
                    Excelencia.generarExcelenciaAleatoria(), 
                    Afinidad.generarAfinidadAleatoria()));
                    break;
                case 1:
                    alumnado.add(new AlumnoHufflepuff(
                    GenerardorNombresMagos.generarNombre(), 
                    promocion, 
                    Excelencia.generarExcelenciaAleatoria(), 
                    Afinidad.generarAfinidadAleatoria()));
                    break;
                case 2:
                    alumnado.add(new AlumnoRavenclaw(
                    GenerardorNombresMagos.generarNombre(), 
                    promocion, 
                    Excelencia.generarExcelenciaAleatoria(), 
                    Afinidad.generarAfinidadAleatoria()));
                    break;
                case 3:
                    alumnado.add(new AlumnoSlytherin(
                    GenerardorNombresMagos.generarNombre(), 
                    promocion, 
                    Excelencia.generarExcelenciaAleatoria(), 
                    Afinidad.generarAfinidadAleatoria()));
                    break;
            
            }

        }
    
    }
    
    public void generarCurso(int promocion){
        Curso c = new Curso(promocion);
        for(Asignaturas a : Asignaturas.values()){
            int rnd = (int)(Math.random()*claustro.length);
            c.asignaturas.add(new Asignatura(a, claustro[rnd]));
        }
        promociones[promocion] = c;
                
    
    }
    
    public Curso obtenerCurso(int promocion){    
        return promociones[promocion];
    }
    
    public void matriculasAnuales(int promocion){
        for(Alumno alu : alumnado){
            alu.matricularCurso(obtenerCurso(promocion));
        }
    
    }
    
    public void evaluarAlumnado(){
        for(Alumno alu : alumnado){
            alu.obtenerResultadosAcademicos();
        }
    }
    
    public void generarIncidencias(int promocion){
        for(Alumno alu : alumnado){
            alu.generarIncidencias(promocion);
        }
    }
    
    public String infoPromocion(int promocion){
        String cad = "\n";
        
        // lista de casas
        for(EnumCasa c : EnumCasa.values()){
            double pAcademicos = 0;
            int pIncidencias = 0;
            cad += "\n**************** " + c.name() + " ****************\n";
        
            // lista cursos
            for(int i = 1; i <= 7; i++){
                double pAcademicosCurso = 0;
                int pIncidenciasCurso = 0;
                int contAlumnos = 0;
                cad += "\n########## CURSO " + i + " ##########\n";
                // lista alumnos en el curso
                for(Alumno a : alumnado){
                    if(a.getCasa() == c){
                        if(a.getPromocion() == (promocion - i + 1)){
                            contAlumnos++;
                            cad += a.getNombre() + "\n";
                            pAcademicosCurso += a.notaMedia(); // no es correcto ya que suma el expediente global, no el del curso, pero me da pereza xD
                            pIncidenciasCurso += a.puntuacionParaLaCasa(); // mismo que arriba
                        }
                    }
                }
                pAcademicosCurso = pAcademicosCurso / contAlumnos;
                cad += "    Nota aportada por el grupo: " + (int)(pAcademicosCurso * 100)+"\n";
                cad += "    Aportaciones a la casa del grupo: " + pIncidenciasCurso+"\n";
                pAcademicos += (pAcademicosCurso * 100);
                pIncidencias += pIncidenciasCurso;
            }
            cad += "\n\nPUNTOS TOTALES DE LA CASA EN LA PROMOCIÓN: " + (int)(pAcademicos + pIncidencias) + "\n";
            
        }
        
        return cad + "\n";
    }
    
    @Override
    public String toString(){
        String cad = "--- HISTORIA ---" + "\n\n";
        
        cad+= "En este escrito se relata la historia del colegio Hogwarts de magia y hechicería durante sus primeros "+
                promociones.length + " años de historia.\n";
        
        // claustro
        cad += "\n...............................................\n";
        cad += "................ CLAUSTRO .....................\n";
        cad += "...............................................\n\n";
        for(Profesor p : claustro){
            cad += p.toString() + "\n";
        }
        
        // promociones
        cad += "\n...............................................\n";
        cad += "................ PROMOCIONES ..................\n";
        cad += "...............................................\n\n";
        for(Curso c : promociones){
            cad += c.toString() + "\n";
            cad += infoPromocion(c.getPromocion());
        }
        
        // alumnos ilustres
        cad += "\n...............................................\n";
        cad += "................ ALUMNOS ILUSTRES .............\n";
        cad += "...............................................\n\n";
        for(Curso c : promociones){
            cad += "Mejor alumno de la promoción " + c.getPromocion() + ": ";
            int maxP = 0;
            String nombreAlumno = "";
            String casaAlumno = "";
            for(Alumno alum : alumnado){
                if(alum.getPromocion() == c.getPromocion()){
                    if (alum.aportacionGlobalAHogwarts() > maxP){
                        maxP = alum.aportacionGlobalAHogwarts();
                        nombreAlumno = alum.getNombre();
                        casaAlumno = alum.getCasa().name();
                    }
                }
            }
            cad += nombreAlumno + " de " + casaAlumno + " con " + maxP + " puntos.\n";
        }
        cad += "\n";
        for(EnumCasa ec : EnumCasa.values()){
            cad += "Mejor alumno de " + ec.name() + ": ";
            int maxP = 0;
            String nombreAlumno = "";
            for(Alumno alum : alumnado){
                if(alum.getCasa() == ec){
                    if (alum.aportacionGlobalAHogwarts() > maxP){
                        maxP = alum.aportacionGlobalAHogwarts();
                        nombreAlumno = alum.getNombre();
                    }
                }
            }
            cad += nombreAlumno + " con " + maxP + " puntos.\n";
        }
        
        cad += "\nHeroe legendario de Hogwarts: ";
        int maxP = 0;
        String nombreAlumno = "";
        String casaAlumno = "";
        String especialidad = "";
        for(Alumno alum : alumnado){            
            if (alum.aportacionGlobalAHogwarts() > maxP){
                maxP = alum.aportacionGlobalAHogwarts();
                nombreAlumno = alum.getNombre();
                casaAlumno = alum.getCasa().name();
                especialidad = alum.getAfinidad().name();
            }            
        }
        cad += nombreAlumno + " especialista en " + especialidad + " de " + casaAlumno + " con " + maxP + " puntos.\n";
        
        
        
        // alumnos
        cad += "\n...............................................\n";
        cad += "................ ALUMNADO .....................\n";
        cad += "...............................................\n\n";
        for(Alumno alum : alumnado){
            cad += alum.toString() + "\n";
        }
        
        
        
        return cad;
    }
    
    
}
