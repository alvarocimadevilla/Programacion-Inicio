package harrypootter.artilugios;

// para generar HTML
public interface InformacionParaMuggles {
    //String toHTML();
}
