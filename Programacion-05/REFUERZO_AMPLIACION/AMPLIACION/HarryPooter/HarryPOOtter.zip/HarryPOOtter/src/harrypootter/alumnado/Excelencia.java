package harrypootter.alumnado;

/**
 * Todos los alumno al generarse aleatoriamente obtienen un modificador de
 * excelencia, que afectará al rendimiento en áreas como los estudios,
 * el quidditch o la puntuación para sus casas. Las probabilidades de cada
 * tipo de alumno son:
 * normal - 60%
 * semimuggle - 17%
 * virtuoso - 17%
 * leyenda - 6%
 */
public enum Excelencia {
    SEMIMUGGLE(0.8d),
    NORMAL(1d),
    VIRTUOSO(1.2d),
    LEYENDA(1.5d);
        
    
    private double modificadorRendimiento;
    private Excelencia(double modificadorRendimiento){
        this.modificadorRendimiento = modificadorRendimiento;
    }
    
    public double rendimiento(){
        return this.modificadorRendimiento;
    }
    
    public static Excelencia generarExcelenciaAleatoria(){
        int rnd = (int)(Math.random()*100);
        if(rnd < 17){
            return SEMIMUGGLE;
        } else if(rnd < 77){
            return NORMAL;
        } else if(rnd < 94){
            return VIRTUOSO;
        } else{
            return LEYENDA;
        }    
    }
    
}
