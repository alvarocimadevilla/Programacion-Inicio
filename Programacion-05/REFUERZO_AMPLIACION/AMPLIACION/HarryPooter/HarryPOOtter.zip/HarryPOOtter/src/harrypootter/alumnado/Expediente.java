package harrypootter.alumnado;

import harrypootter.hogwarts.Asignatura;
import harrypootter.hogwarts.Incidencia;
import java.util.ArrayList;


public class Expediente {
    private static final int NUMERO_CURSOS = 7;
    private ArrayList<Asignatura> asignaturas;
    private ArrayList<Double> calificaciones;
    public ArrayList<Incidencia> incidencias;
    private boolean[] jugadorQuidditch;
    private boolean prefectoEnCuartoCurso;

    public Expediente() {
        asignaturas = new ArrayList<Asignatura>();
        calificaciones = new ArrayList<Double>();
        incidencias = new ArrayList<Incidencia>();
        jugadorQuidditch = new boolean[NUMERO_CURSOS];
    }
    
    public void addAsignatura(Asignatura asignatura){
        asignaturas.add(asignatura);
        calificaciones.add(-1d);
    }

    public ArrayList<Asignatura> getAsignaturas() {
        return asignaturas;
    }

    public ArrayList<Double> getCalificaciones() {
        return calificaciones;
    }
    
    
    
    
    @Override
    public String toString(){
        String cad = "--- Expediente académico ---" + "\n";
        for(int i = 0; i < asignaturas.size(); i++){
            cad += "  " + asignaturas.get(i).toString();
            cad += " Calificación: " + String.format("%.2f", calificaciones.get(i)) + "\n";
        }
        cad += "--- Premios y castigos ---" + "\n";
        for(int i = 0; i < incidencias.size(); i++){
            cad += "  " + incidencias.get(i).toString() + "\n";
            
        }
        return cad;
    }
    
    
    
}
