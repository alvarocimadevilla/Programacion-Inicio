package harrypootter;

import harrypootter.artilugios.Pensadero;
import harrypootter.hogwarts.Historia;

public class HarryPOOtter {

    private static final int NUMERO_PROMOCIONES = 15;
    //private static final int PROMOCION_PROTAGONISTA = 7;
    
    public static void main(String[] args) {
        
        
        // generar un historial (informe inicial)
        Historia historia = new Historia(NUMERO_PROMOCIONES);
        
        // se genera claustro de profesores (informe del claustro)
        historia.generarClaustro();
        
        
        // bucle para generar cursos
        for (int promocion = 0; promocion < NUMERO_PROMOCIONES; promocion++) {
            
        
            // se promocionan los cursos
            
            // se generan nuevos alumnos que entran a primero
            historia.generarAlumnos(promocion);
            
            // se asignan profesores a matriculas
            historia.generarCurso(promocion);
            
            // se inicializan las matrículas (promocion+curso-1 == curso actual){matricula}
            historia.matriculasAnuales(promocion);
            
            // se asignan jugadores quidditch
              //TODO: LO HACEN LOS ALUMNOS
            
            
            // se obtienen calificaciones
            historia.evaluarAlumnado();
            
            // se juega la liga de quidditch
                //TODO: LO HACEN LOS ALUMNOS
            
            // se generan acciones positivas y negativas
            historia.generarIncidencias(promocion);
            
            // nombrar casa ganadora en cada promoción con puntuación total
                //TODO: LO HACEN LOS ALUMNOS
            
        }
            

        Pensadero p = new Pensadero();
        p.legarRecuerdo(historia.toString());
        p.sublimarRecuerdos("historia.txt");
    }
    
}
