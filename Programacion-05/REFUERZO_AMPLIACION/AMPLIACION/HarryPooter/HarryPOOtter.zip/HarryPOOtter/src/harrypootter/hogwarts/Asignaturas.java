package harrypootter.hogwarts;

public enum Asignaturas {
    Astronomia1("Astronomía", 1, Afinidad.NATURAL),
    Encantamientos1("Encantamientos", 1, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras1("Defensa contra las artes oscuras", 1, Afinidad.OSCURIDAD),
    Herbologia1("Herbología", 1, Afinidad.NATURAL),
    Pociones1("Pociones", 1, Afinidad.NATURAL),
    Transfiguracion1("Transfiguraciones", 1, Afinidad.ANTILEY),
    Vuelo("Vuelo", 1, Afinidad.ANTILEY),

    Astronomia2("Astronomía", 2, Afinidad.NATURAL),
    Encantamientos2("Encantamientos", 2, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras2("Defensa contra las artes oscuras", 2, Afinidad.OSCURIDAD),
    Herbologia2("Herbología", 2, Afinidad.NATURAL),
    Pociones2("Pociones", 2, Afinidad.NATURAL),
    Transfiguracion2("Transfiguraciones", 2, Afinidad.ANTILEY),
    HistoriaDeLaMagia("Historia de la magia", 2, Afinidad.ARCANA),

    Astronomia3("Astronomía", 3, Afinidad.NATURAL),
    Encantamientos3("Encantamientos", 3, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras3("Defensa contra las artes oscuras", 3, Afinidad.OSCURIDAD),
    Herbologia3("Herbología", 3, Afinidad.NATURAL),
    Pociones3("Pociones", 3, Afinidad.NATURAL),
    Transfiguracion3("Transfiguraciones", 3, Afinidad.ANTILEY),
    CuidadoDeCriaturasMagicas("Cuidado de criaturas mágicas", 3, Afinidad.NATURAL),

    Astronomia4("Astronomía", 4, Afinidad.NATURAL),
    Encantamientos4("Encantamientos", 4, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras4("Defensa contra las artes oscuras", 4, Afinidad.OSCURIDAD),
    Herbologia4("Herbología", 4, Afinidad.NATURAL),
    Pociones4("Pociones", 4, Afinidad.NATURAL),
    Transfiguracion4("Transfiguraciones", 4, Afinidad.ANTILEY),
    RunasAntiguas("Runas antiguas", 4, Afinidad.ARCANA),

    Astronomia5("Astronomía", 5, Afinidad.NATURAL),
    Encantamientos5("Encantamientos", 5, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras5("Defensa contra las artes oscuras", 5, Afinidad.OSCURIDAD),
    Herbologia5("Herbología", 5, Afinidad.NATURAL),
    Pociones5("Pociones", 5, Afinidad.NATURAL),
    Transfiguracion5("Transfiguraciones", 5, Afinidad.ANTILEY),
    EstudioDeLosNigromantes("Estudio de los nigromantes", 5, Afinidad.OSCURIDAD),

    Astronomia6("Astronomía", 6, Afinidad.NATURAL),
    Encantamientos6("Encantamientos", 6, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras6("Defensa contra las artes oscuras", 6, Afinidad.OSCURIDAD),
    Herbologia6("Herbología", 6, Afinidad.NATURAL),
    Pociones6("Pociones", 6, Afinidad.NATURAL),
    Transfiguracion6("Transfiguraciones", 6, Afinidad.ANTILEY),
    Aparicion("Aparición", 6, Afinidad.ANTILEY),
    Oclumancia("Oclumancia", 6, Afinidad.ARCANA),

    Astronomia7("Astronomía", 7, Afinidad.NATURAL),
    Encantamientos7("Encantamientos", 7, Afinidad.ARCANA),
    DefensaContraLasArtesOscuras7("Defensa contra las artes oscuras", 7, Afinidad.OSCURIDAD),
    Herbologia7("Herbología", 7, Afinidad.NATURAL),
    Pociones7("Pociones", 7, Afinidad.NATURAL),
    Transfiguracion7("Transfiguraciones", 7, Afinidad.ANTILEY),
    Sanadores("Sanadores", 7, Afinidad.NATURAL),
    EstudioDeLosDragones("Estudio de los dragones", 7, Afinidad.NATURAL);

    private final String nombre;
    private final int curso;
    private final Afinidad afinidad;


    private Asignaturas(String nombre, int curso, Afinidad afinidad){
        this.nombre = nombre;
        this.curso = curso;
        this.afinidad = afinidad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCurso() {
        return curso;
    }

    public Afinidad getAfinidad() {
        return afinidad;
    }


    
    





}
