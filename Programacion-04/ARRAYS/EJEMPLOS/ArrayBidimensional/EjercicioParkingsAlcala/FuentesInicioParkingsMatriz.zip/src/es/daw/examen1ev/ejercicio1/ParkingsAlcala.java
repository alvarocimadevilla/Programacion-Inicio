package es.daw.examen1ev.ejercicio1;

/*
 * Módulo de Programación
 * Examen primera evaluación 2022-23
 * Ejercicio 1
 */

public class ParkingsAlcala {
    
    
    
    //ARRAY CONSTANTE: Nombre de los cuatro parkings públicos de Alcalá
    public static final String[] NOMBRE_PARKINGS = {"El Mercado","San Lucas","Obispado","La Paloma"};
    
    //ARRAY CONSTANTE: Nombre de los cuatro tipos de vehículos con plazas de aparcamiento en los parkings de Alcalá
    public static final String[] NOMBRE_VEHICULOS = {"coche","moto","furgoneta","camión"};
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("**BIENVENIDO AL SISTEMA DE INFORMACIÓN DE PLAZAS DE APARCAMIENTO DE ALCALÁ DE HENARES **");
        
        // 1. CARGAR LOS DATOS DIRECTAMENTE AL INICIAR EL PROGRAMA ( utiliza Utilidades.cargarDatos() )
        
        // Pendiente completar...
        
        // 2. MOSTRAR EL MENÚ Y SE GESTIONAR LAS DIFERENTES OPCIONES DEL MISMO
        
        // Pendiente completar...
        
        
    }
    
}
