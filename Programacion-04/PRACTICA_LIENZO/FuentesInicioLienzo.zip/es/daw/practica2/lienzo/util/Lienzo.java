/**
 * Clase que contiene métodos estáticos (funciones) específicos del lienzo
 */
package es.daw.practica2.lienzo.util;

import static es.daw.practica2.lienzo.AppLienzo.NUM_COLS;
import static es.daw.practica2.lienzo.AppLienzo.letras;


/**
 *
 * @author melol
 */
public class Lienzo {
    
    // Inicializamos el arrays del lienzo: array bidimensional 26x25 (26 filas y 25 columnas)
    static String[][] lienzo = new String[letras.length][NUM_COLS];
    
    /**
     * Función para dibujar los marcos laterales del lienzo, el contenido del lienzo y el marco inferior
     * @param lienzo 
     */
    public static void dibujarLienzo(){
        
        // marco superior números
        System.out.print("         "); // 9 espacios
        for(int i = 0; i < lienzo[0].length; i++){
            if (i < 9)
                System.out.print((i+1)+"   "); // 3 espacios
            else
                System.out.print((i+1)+"  "); // 2 espacios
        }
        
        // marco superior con @
        System.out.print("\n     @"); // 5 espacios
        for(int i = 1; i < lienzo[0].length+1; i++){
            System.out.print("   @"); // 3 espacios
        }
        System.out.println("   @"); //3 espacios y última arroba del marco superior

        // lienzo
        for(int i = 0; i < lienzo.length; i++){
            System.out.print("  " + letras[i] + "  @"); // 2 espacios + letra + 2 espacios + @
            for(int j = 0; j < lienzo[i].length; j++){
                System.out.print("   "+lienzo[i][j]); // 3 espacios de separación
            }
            System.out.println("   @"); // 3 espacios
        }
        System.out.print("     @"); // 5 espacios
        
        
        // marco inferior
        for(int j = 0; j < lienzo[0].length; j++){
            System.out.print("   @"); // 3 espacios
        }
        System.out.println("   @\n"); // 3 espacios
        
        
    }
    
    /**
     * Función para limpiar el lienzo dejandolo con '.'
     */
    public static void limpiarLienzo(){
        for(int i = 0; i<lienzo.length; i++){
            for(int j = 0; j<lienzo[i].length; j++){
                    lienzo[i][j]= ".";
            }
        }
    }
    
    /**
     * Función para dibujar el lienzo completo (marco y contenido)
     */
    public static void dibujarCuadro(){
        limpiarLienzo(); // lienzo inicializado con puntos
        dibujarLienzo(); // se dibuja el lienzo completo con marco y su contenido
    }
    
}
