/**
 * Clase principal ejecutable de la herramienta LIENZO
 * 
 */
package es.daw.practica2.lienzo;

import static es.daw.practica2.lienzo.util.Lienzo.dibujarCuadro;
import static es.daw.practica2.lienzo.util.Utils.*;


public class AppLienzo {

    // Variables globales
    public static final char[] letras = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    public static final int NUM_COLS = 25;
    
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        
        System.out.println("[LIENZO DAW - DIBUJAR POR CONSOLA] Realizado por XXXXXXX");
        System.out.println("Pulsa intro para mostrarte el lienzo");
        
        leerEnter();
        dibujarCuadro();
        menuOpciones();
        
        
    }

}
